# Assignment 2 
### Ruben Schut


----
Please run the following command to install dependencies:
```pip3 install -r requirments.txt```

---
Run instructions:
```python3 main.py <trainset> <testset>```